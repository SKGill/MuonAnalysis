#Automatically created by SCRAM
import os
__path__.append(os.path.dirname(os.path.abspath(__file__).rsplit('/MuonAnalysis/Cosmics/',1)[0])+'/cfipython/slc5_amd64_gcc462/MuonAnalysis/Cosmics')
